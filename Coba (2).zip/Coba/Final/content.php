<?php

 $queries = array();
      parse_str($_SERVER['QUERY_STRING'], $queries);
      error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));

      
	if ($_GET['act']=='dashboard'){
		include 'admin/module/dashboard/dashboard.php';
	}
	
	elseif ($_GET['act']=='obat'){
		include 'admin/module/obat/obat.php';}

	elseif ($_GET['act']=='kategori'){
		include 'admin/module/kategori/kategori.php';}		

	elseif ($_GET['act']=='pemasok'){
		include 'admin/module/pemasok/pemasok.php';}	

	elseif ($_GET['act']=='penjualan'){
		include 'admin/module/penjualan/penjualan.php';}


	elseif ($_GET['act']=='pembelian'){
		include 'admin/module/pembelian/pembelian.php';}

	elseif ($_GET['act']=='profilApotek'){
		include 'admin/module/profile_apotek/profile_apotek.php';}	

	elseif ($_GET['act']=='laporan'){
		include 'admin/module/laporan/laporan.php';}

	elseif ($_GET['act']=='logout'){
		include 'admin/module/logout/logout.php';}			
	
	else {
		include 'admin/module/dashboard/dashboard.php';
	}
?>