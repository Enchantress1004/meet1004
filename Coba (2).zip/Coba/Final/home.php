<?php 
    error_reporting(0);

    session_start();

    if (!isset($_SESSION['login'])) {
      header('location:index.php');
    }
 ?>


<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href='http://fonts.googleapis.com/css?family=Viga' rel='stylesheet' type='text/css'>

  <link rel="stylesheet" type="text/css" href="file/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="file/css/style.css">
  <link rel="stylesheet" type="text/css" href="file/fonts/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="file/fontawesome-free/css/all.min.css">


  <title>Apotek Medika Parma</title>
</head>
<body>


  <nav class="navbar navbar-expand-lg navbar-light bg-info">
    <div class="container">
      <a class="navbar-brand" href="?act=dashboard" style="color: white;">Medika Parma</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="?act=dashboard">Dashboard 
              <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="?act=obat">Obat</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="?act=kategori">Kategori</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="?act=pemasok">Pemasok</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="?act=penjualan">Penjualan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="?act=pembelian">Pembelian</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="?act=profilApotik">Profil Apotik</a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="?act=laporan">Laporan</a>
            </li>
            <li class="nav-item pull-right">
              <a class="btn btn-danger tombol" href="?act=logout">Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container">
     <div class="content">
       <div class="card mt-5">
        <div class="card-body">
          <?php 
          include 'content.php';
          ?>
        </div>
      </div>

    </div>
  </div>


  

  <script src="file/js/jquery-3.5.1.js"></script>
  <script src="file/js/bootstrap.min.js"></script> 




</body>
</html>