<?php
include 'config/koneksi.php';
session_start();

$pass = md5($_POST['password']);
$username = mysqli_escape_string($koneksi, $_POST['username']);
$password = mysqli_escape_string($koneksi, $pass);


//cek username, terdaftar atau tidak
$cek_user = mysqli_query($koneksi, "SELECT * FROM login WHERE username = '$username' and password='$password' ");
$user_valid = mysqli_fetch_array($cek_user);
//uji jika username terdaftar
if ($user_valid) {
    //jika username terdaftar
    //cek password sesuai atau tidak
            if ($username == $user_valid['username']) {
                //jika password sesuai
                //buat session
                session_start();

                $_SESSION['username'] = $user_valid['username'];
                $_SESSION['password'] = $user_valid['password'];
               

                $_SESSION['login'] = true;
                
                header('location:home.php'); 

                } else{
                 header("location:index.php?log=2");
                }

            }else{
            echo "<script>alert('Maaf, Login Gagal, Username anda tidak Ada!');document.location='index.php'</script>";
        }

            