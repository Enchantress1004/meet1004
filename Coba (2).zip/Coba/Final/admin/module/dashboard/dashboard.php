<?php 


$aksi = 'action/admin/adminAksi.php';
include 'config/koneksi.php';


	$query1 = mysqli_query($koneksi, "SELECT * FROM kategori ") or die(mysqli_error());
	$data1 = mysqli_fetch_array($query1);
	$kategori = mysqli_num_rows($query1);

	$query2 = mysqli_query($koneksi, "SELECT * FROM pemasok ") or die(mysqli_error());
	$data2 = mysqli_fetch_array($query2);
	$pemasok = mysqli_num_rows($query2);

	$query3 = mysqli_query($koneksi, "SELECT * FROM obat ") or die(mysqli_error());
	$data3 = mysqli_fetch_array($query3);
	$obat = mysqli_num_rows($query3);


	switch ($_GET["page"]) {
		
		default:
		echo "<h3 mt-3> Dashboard</h3><hr>";
			echo "

			<div class='card bg-success' style='width: 62.5rem;'>
					  <div class='card-body'>
					  	<div class='card-body-icon text-white' style='position: absolute; z-index:0; top:25px; right:4px; opacity:0.4; font-size:90px;'>
					  		
					  	</div>
					    <h4 class='card-title text-white'>Welcome, Anda login sebagai Admin.</h4>
					    <p class='card-text'></p>
					    
					  </div>
					</div>
		
			<div class='container'>
			  <div class='row'>
			    <div class='col-sm mt-4'>
			     					<div class='row mr-3'>
			<div class='card bg-info' style='width: 18rem;'>
					  <div class='card-body'>
					  	<div class='card-body-icon text-white' style='position: absolute; z-index:0; top:25px; right:4px; opacity:0.4; font-size:90px;'>
					  		
					  	</div>
					    <h4 class='card-title text-white'>JUMLAH OBAT</h4>
					    <div class='display-4 text-white mt-2'>$obat</div>
					    <p class='card-text'></p>
					    
					  </div>
					</div>
			</div>
			    </div>
			    <div class='col-sm mt-4'>
			      <div class='row mr-3'>
			<div class='card bg-warning' style='width: 18rem;'>
					  <div class='card-body'>
					  	<div class='card-body-icon text-white' style='position: absolute; z-index:0; top:25px; right:4px; opacity:0.4; font-size:90px;'>
					  		
					  	</div>
					    <h4 class='card-title text-white'>JUMLAH PEMASOK</h4>
					    <div class='display-4 text-white mt-2'>$pemasok</div>
					    <p class='card-text'></p>
					    
					  </div>
					</div>
			</div>
			    </div>
			    <div class='col-sm mt-4'>
			     				<div class='row mr-3'>
			<div class='card bg-primary' style='width: 18rem;'>
					  <div class='card-body'>
					  	<div class='card-body-icon text-white' style='position: absolute; z-index:0; top:25px; right:4px; opacity:0.4; font-size:90px;'>
					  		
					  	</div>
					    <h4 class='card-title text-white'>JUMLAH KATEGORI</h4>
					    <div class='display-4 text-white mt-2'>$kategori</div>
					    <p class='card-text'></p>
					    
					  </div>
					</div>
			</div>
			    </div>
			  </div>
			</div>

		
			";
			break;

		
	}

 ?>