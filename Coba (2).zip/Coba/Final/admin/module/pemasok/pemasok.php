<?php 


$aksi = 'admin/module/obat/aksi_obat.php';
include 'config/koneksi.php';

	switch ($_GET["page"]) {
		
		default:
			
			echo "<h3 mt-3></i> Data Pemasok</h3><hr>";

			echo "<a class='tombol btn btn-primary mb-2'  href='?act=pemasok&page=tambahDataPemasok'><i class='fa fa-plus'></i> Tambah Data Pemasok</a>
					<div class='table-responsive'>
				    <table  id='example' class='table table-bordered mt-2' style='width:100%' >
				    <thead>
				    	<tr align='center' class='bg-light'>
				    		
				    			<th style='width:3%;'>No.</th>
					 			<th>Nama Pemasok</th>
					 			<th>Alamat</th>
					 			<th>No. Telp</th>
					 			<th>Aksi</th>
				    		
				 		</tr>
				 	</thead>";
	 			$query = mysqli_query($koneksi, "SELECT * FROM pemasok") or die(mysqli_error());
	 			$nomor = 0;
	 			while ($data = mysqli_fetch_array($query)) {
	 			$nomor++;
	 	
	 	echo "<tr >
	 			<td align='center'>$nomor</td>
	 			<td>$data[nama_pemasok]</td>
	 			<td>$data[alamat]</td>
	 			<td>$data[telepon]</td>
	 			
	 			<td align='center'>
	 				<a class='hapus btn btn-warning' data-toggle='tooltip' data-placement='top' title='EDIT DATA' href='?act=kategori&page=editDataKategori&id=$data[id_kategori]'><i class='fas fa-edit'></i></a>
	 				
	 				<a class='hapus btn btn-danger'  data-toggle='tooltip' data-placement='top' title='HAPUS DATA'  href='$aksi?act=obat&page=hapus&del=$data[id_obat]'><i class='fas fa-trash-alt'></i></a>
	 			</td>
	 		</tr>";
	 			}
	 	echo"</table>";
			break;

		case 'tambahDataPemasok':
			echo "<h3 mt-3> Input Data Pemasok</h3><hr>";
			echo "<div class='card' style='width: 40rem;'>
					  <div class='card-body'>
					   	<form method='post' action='$aksi?act=pemasok&page=input' >
			    	<div class='form-group'>
					    		<label><b>ID Pemasok</b></label>
					    		<input type='text' name='id_pemasok' class='form-control' placeholder='Input Id Pemasok' required>
					    	</div>
					    	<div class='form-group'>
					    		<label><b>Nama Pemasok</b></label>
					    		<input type='text'  name='nama_pemasok'  class='form-control' placeholder='Input Nama Pemasok' required>
					    	</div>
					    	<div class='form-group'>
					    		<label><b>Alamat</b></label>
					    		<textarea type='textarea' name='alamat' class='form-control' placeholder='Input Alamat'></textarea>
					    	</div>
					    	<div class='form-group'>
					    		<label><b>Telp/WA</b></label>
					    		<input type='text'  name='telepon'  class='form-control' placeholder='Input Nomor Telp' required>
					    	</div>
					    	
					    	<button type='submit' class='btn btn-primary' ><i class='far fa-save'></i> SIMPAN</button>
					    	<button type='button' onclick='self.history.back()' class='btn btn-danger '><i class='fas fa-undo'></i> KEMBALI</button>

			    		</form>
					  </div>
					</div>"	;
			break;


		case 'editDataObat':

			$id_obat = $_GET['id_obat'];
			$query = mysqli_query($koneksi, "SELECT * FROM obat WHERE id_obat='$_GET[id]' ")or die(mysqli_error());
			$data=mysqli_fetch_array($query);   

			echo "<h3 mt-3> Edit Data Obat</h3><hr>";
			echo "<div class='card' style='width: 40rem;'>
					  <div class='card-body'>
						<form method='post' action='$aksi?act=obat&page=update'>
					    	<div class='form-group'>
					    		<label><b>NIP (Nomor Induk Pegawai)</b></label>
					    		<input type='text' class='form-control' name='nip' value='$data[id_obat]' readonly>
								<input type='hidden' class='form-control' name='id' value='$data[id_obat]'>
					    	</div>
					    	<div><p></p></div>
					    	<div class='form-group'>
					    		<label><b>Nama Obat</b></label>
					    		<input type='text' class='form-control' name='nama' value='$data[nama_obat]'>
					    	</div>
					    	<div class='form-group'>
					    		<label><b>Kategori</b></label>
					    		<select  name='kategori' class='form-control' >";
								 	$kategori=mysqli_query($koneksi,"SELECT * FROM kategori");
										 if ($data[id_kategori]==0){
											echo "<option value=0 selected>-- Pilih Kategori --</option>";
										  }   
										while($kt=mysqli_fetch_array($kategori)){
											if ($data[id_kategori]==$kt[id_kategori]){
											  echo "<option value=$kt[id_kategori] selected>$kt[id_kategori] ~ $kt[nama_kategori]</option>";
											}
											else{
												echo "<option value='$kt[id_kategori]'> $kt[id_kategori] ~ $kt[nama_kategori]</option>";
											}
										}
							echo"</select>
							</div>
					    	<div class='form-group'>
					    		<label><b>Tempat Penyimpanan</b></label>
					    		<input type='text'  name='penyimpanan'  class='form-control' placeholder='Input Tempat Penyimpanan' value='$data[penyimpanan]' required>
					    	</div>
					    	<div class='form-group'>
					    		<label><b>Kadaluarsa</b></label>
					    		<input type='date'  name='kadaluarsa' value='$data[kadaluarsa]' class='form-control' required>
					    	</div>
				
					    	<div class='form-group'>
					    		<label><b>Stok</b></label>
					    		<input type='number'  name='stok' value='$data[stok]'  class='form-control' placeholder='Input Jumlah Stok' required>
					    	</div>
						    <div class='form-group'>
					    		<label><b>Harga</b></label>
					    		<input type='text'  name='harga' value='$data[harga]' class='form-control' placeholder='Input Harga' required>
					    	</div>
					    	<div class='form-group'>
					    		<label><b>Unit</b></label>
					    		<input type='text'  name='unit' value='$data[unit]'  class='form-control' placeholder='Input Unit Obat' required>
					    	</div>
					    	<button type='submit' class='btn btn-primary' ><i class='fa fa-sync-alt'></i> UPDATE</button>

				    </form>
					  </div>
					</div>"	;
			echo "";
				
			break;
		
	}

 ?>