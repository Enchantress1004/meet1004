
<?php

	include '../../../config/koneksi.php';
	//include '../config/koneksi.php';

	$act = $_GET['act'];
	$page = $_GET['page'];

	// Hapus - memnggil file admindel.php
	if ($act=='obat' AND $page=='hapus'){
		

		$query = ("DELETE FROM obat WHERE id_slip='$_GET[del]'");

		mysqli_query($koneksi, $query);
		header('location:../../homeAdmin.php?action='.$action);
	}

	// Input - memanggil file adminsim.php
	elseif ($act=='obat' AND $page=='input'){
		$nip = $_POST['nip'];
		$nama = $_POST['nama'];
		$tot_gaji = $_POST['tot_gaji'];


		$query = ("INSERT INTO slip_gaji SET nip='$nip', nama='$nama', kode_jabatan='$kode_jabatan', tot_gaji='$tot_gaji'");

		mysqli_query($koneksi, $query);  
	header('location:../../homeAdmin.php?action='.$module);
	}

	// Update - memnggil file admineditsim.php
	elseif ($act=='obat' AND $page=='update'){
		//$id = $_POST[id];
		//$username = $_POST['username'];
		$password = $_POST['password'];
		$nama_lengkap = $_POST['nama_lengkap'];


		$query = ("UPDATE data_admin SET password='$password', nama_lengkap='$nama_lengkap' WHERE username='$_POST[id]' ");

		mysqli_query($koneksi, $query); 
	header('location:../../homeAdmin.php?action='.$action);
	}

?>
