 <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">

              <div class="row">
                  <div class="col-lg-12 main-chart">
						<h3>Data Laporan
							
							<a style="padding-left:2pc;" href="index.php?page=laporan">
								<button class="btn btn-success">Refresh</button></a>
						</h3>
						<br/>
						<h4>Cari Laporan Per Perbulan</h4>
						<!-- view barang -->	
						<div class="modal-view">
							<table class="table table-bordered" id="example1">
								<thead>
									<tr>
										<td> No</td>
										<td> ID Barang</td>
										<td> Nama Barang</td>
										<td style="width:10%;"> Jumlah</td>
										<td style="width:20%;"> Total</td>
										<td> Kasir</td>
										<td> Tanggal Input</td>
									</tr>
								</thead>
								<tbody>
								<?php 	 			
									$query = mysqli_query($koneksi, "SELECT * FROM laporan");
									$no = 0;
									while ($isi = mysqli_fetch_array($query)) {
									
									?>
									<tr>
										<td><?php echo $no;?>ss</td>
										<td><?php echo $isi['id_barang'];?></td>
										<td><?php echo $isi['nama_obat'];?></td>
										<td><?php echo $isi['jumlah'];?> </td>
										<td>Rp.</td>
										<td><?php echo $isi['nm_member'];?></td>
										<td><?php echo $isi['tanggal_input'];?></td>
									</tr>
									<?php }?>
								</tbody>
							</table>
						
							
						</div>
					
					</div>
				  </div>
              </div>
          </section>
      </section>
	

