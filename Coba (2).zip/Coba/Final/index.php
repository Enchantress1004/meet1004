<?php 

session_start();

if (isset($_SESSION['login'])) {
	header('location:home.php');
}

?>




<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login Apotek Medika Parma</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="dist/style.css">
	<style>
		body {
			background-image: url(assets/img/bg.jpg);
			

		}

	</style>

</head>
<body>

	<div class="container">
		<div class="kotak_login">
			<p class="tulisan_login"><strong>Silahkan login</strong></p>

			<form action="cek_login.php" method="POST">
				<label class="mt-3">Username</label>
				<input type="text" name="username" class="form-control" placeholder="Username" required="required">

				<label class="mt-3">Password</label>
				<input type="password" name="password" class="form-control" placeholder="Password .." required="required">

				<input type="submit" class="tombol_login mt-3" value="LOGIN" name="login">

				<br/>
				<br/>
				<center>
					<a >kembali</a>
				</center>
			</form>

		</div>
	</div>
</body>
</html>

